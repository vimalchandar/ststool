package com.cg.ITrainingService;

import java.util.List;

import com.cg.entities.TrainingDetails;

public interface TrainingService {
	public TrainingDetails save(TrainingDetails trainingDetails);
	public List<TrainingDetails> loadAll();

}
