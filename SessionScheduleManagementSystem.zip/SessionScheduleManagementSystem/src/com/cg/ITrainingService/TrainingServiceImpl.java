package com.cg.ITrainingService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.ITrainingDAO.TrainingRepository;
import com.cg.entities.TrainingDetails;


@Service
@Transactional
public class TrainingServiceImpl implements TrainingService{
	
	@Autowired
	TrainingRepository trainingRepository;

	@Override
	public TrainingDetails save(TrainingDetails trainingDetails) {
		// TODO Auto-generated method stub
		return trainingRepository.save(trainingDetails);
	}

	@Override
	public List<TrainingDetails> loadAll() {
		// TODO Auto-generated method stub
		return trainingRepository.loadAll();
	}

}
