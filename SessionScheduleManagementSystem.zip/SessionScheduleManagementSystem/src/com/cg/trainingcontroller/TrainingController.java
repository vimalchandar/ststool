package com.cg.trainingcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;

import com.cg.ITrainingService.TrainingService;

import com.cg.entities.TrainingDetails;

@Controller
public class TrainingController {
	
	@Autowired
	TrainingService trainingService;
	
	
	@RequestMapping(value="/save") 
	public String saveEmployee(@ModelAttribute("session") TrainingDetails trainingDetails, Model model)
	{
		trainingDetails = trainingService.save(trainingDetails);
		model.addAttribute("message","Training details added successfully");
		//return "ScheduledSessions";
		return "redirect:/ScheduledSessions.html";
	}
	
	@RequestMapping(value="/ScheduledSessions")
	public String getHomePage(Model model)
	{
		model.addAttribute("empList",trainingService.loadAll());
		model.addAttribute("designations",new String[] {"ILT","VC"});
		model.addAttribute("session",new TrainingDetails());
		return "ScheduledSessions";
	}
	
	@RequestMapping(value="/Success")
	public String salary(@RequestParam("enroll") String double1,Model model) {
		model.addAttribute(double1, model);
		return "Success";
	}
	

}
