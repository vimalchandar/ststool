package com.cg.entities;

import com.sun.xml.internal.ws.developer.Serialization;

@Serialization
public class TrainingDetails {
	private String sessionName;
	private int days;
	private String facultyName;
	private String mode;
	public TrainingDetails() {
		
	}
	
	public TrainingDetails(String sessionName, int days, String facultyName, String mode) {
		super();
		this.sessionName = sessionName;
		this.days = days;
		this.facultyName = facultyName;
		this.mode = mode;
	}
	public String getSessionName() {
		return sessionName;
	}
	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}
	public int getDays() {
		return days;
	}
	public void setDays(int days) {
		this.days = days;
	}
	public String getFacultyName() {
		return facultyName;
	}
	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	
	
	

}
