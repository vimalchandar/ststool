package com.cg.ITrainingDAO;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.TrainingDetails;

@Repository
public class TrainingRepositoryImpl implements TrainingRepository{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public TrainingDetails save(TrainingDetails trainingDetails) {
		// TODO Auto-generated method stub
		entityManager.persist(trainingDetails);
		entityManager.flush();
		return trainingDetails;
	}

	@Override
	public List<TrainingDetails> loadAll() {
		// TODO Auto-generated method stub
		TypedQuery<TrainingDetails> query=entityManager.createQuery("SELECT e FROM TrainingDetails e",TrainingDetails.class);
		return query.getResultList();
	}

}
