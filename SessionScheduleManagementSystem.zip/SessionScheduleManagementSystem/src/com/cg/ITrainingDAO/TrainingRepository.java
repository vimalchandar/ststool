package com.cg.ITrainingDAO;

import java.util.List;

import com.cg.entities.TrainingDetails;

public interface TrainingRepository {
	public TrainingDetails save(TrainingDetails trainingDetails);
	public List<TrainingDetails> loadAll();

}
